# PkgSafe GA Candidate Evidence

Generated: 2026-06-30T09:00:27Z

## Readiness

- Current stage: PRODUCTION_GA_READY
- Private beta ready: true
- GA ready: true
- Real repo validations: 15 / 15

## Benchmark Summary

- Repos passed / failed: 15 / 0
- npm / PyPI / Go / Cargo repos: 12 / 4 / 0 / 0
- Average / p95 scan duration: 6ms / 15ms

## Ecosystem Depth

- npm: production-ready GA v1 scope after GA evidence gates pass
- pypi: preview coverage; not npm-equivalent
- go: preview metadata and OSV-oriented coverage; not npm-equivalent
- cargo: preview metadata and OSV-oriented coverage; not npm-equivalent

## Behavior Analysis

Private beta defaults behavior analysis to disabled. Heuristic mode is host execution; isolated mode reports unavailable until a real isolation backend exists.

## Security Gates

- rollout_readiness: pass: PRIVATE_BETA_READY
- policy_validation: pass: default policy is valid
- ci_outputs: pass: JSON, SARIF, and Markdown outputs generated
- OSV DB: pass: OSV database is initialized

## Release Artifacts

- signing_verified: true
- checksums: verified
- checksums_verified: true
- sbom: present
- sbom_verified: true
- provenance: verified
- provenance_verified: true
- signed_release: signed

## Known Limitations

- Real repo validation count may be below GA threshold.
- Isolated behavior backend is not implemented.
- PyPI/Go/Cargo remain preview until depth parity is implemented and validated.

## Recommendation

PRODUCTION_GA_READY: all GA hardening gates verified.
