# PkgSafe GA Candidate Evidence

Generated: 2026-07-01T07:37:06Z

## Readiness

- Current stage: PRIVATE_BETA_READY
- Private beta ready: true
- GA ready: false
- Real repo validations: 15 / 15
- GA blocker: signed release artifacts not verified locally
- GA blocker: build provenance not verified locally

## Benchmark Summary

- Repos passed / failed: 15 / 0
- npm / PyPI / Go / Cargo repos: 12 / 4 / 0 / 0
- Average / p95 scan duration: 1ms / 2ms

## Ecosystem Depth

- npm: production-ready GA v1 scope after GA evidence gates pass
- pypi: preview coverage; not npm-equivalent
- go: preview metadata and OSV-oriented coverage; not npm-equivalent
- cargo: preview metadata and OSV-oriented coverage; not npm-equivalent

## Behavior Analysis

Private beta defaults behavior analysis to disabled. Heuristic mode is host execution; isolated mode is experimental, Linux-only, and unavailable unless bubblewrap isolation is available.

## Security Gates

- policy_validation: pass: default policy is valid
- ci_outputs: pass: JSON, SARIF, and Markdown outputs generated
- rollout_readiness: pass: PRIVATE_BETA_READY
- OSV DB: pass: OSV database is initialized

## Release Artifacts

- sbom_verified: true
- provenance: configured
- provenance_verified: false
- signed_release: configured
- signing_verified: false
- checksums: verified
- checksums_verified: true
- sbom: present

## Known Limitations

- Real repo validation count may be below GA threshold.
- Isolated behavior backend is experimental, Linux-only, and requires bubblewrap.
- PyPI/Go/Cargo remain preview until depth parity is implemented and validated.

## Recommendation

PRIVATE_BETA_READY: foundation gates passed; continue GA hardening (online benchmark, signed release, provenance, real-repo validation).
