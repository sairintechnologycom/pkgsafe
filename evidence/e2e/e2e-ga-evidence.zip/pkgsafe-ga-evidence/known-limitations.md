# Known Limitations

- Real repo validation count may be below GA threshold.
- Isolated behavior backend is experimental, Linux-only, and requires bubblewrap.
- PyPI/Go/Cargo remain preview until depth parity is implemented and validated.

## Rollout Limitations
- PkgSafe GA v1 is scoped as npm-first supply-chain scanning.
- PyPI, Go, and Cargo are preview coverage and are not npm-equivalent yet.
- heuristic behavior mode executes on the host and is not sandboxing.
- isolated behavior mode is experimental, Linux-only, and unavailable unless bubblewrap isolation is available.
- GA remains blocked until real repository validation and release-integrity verification thresholds are met.
