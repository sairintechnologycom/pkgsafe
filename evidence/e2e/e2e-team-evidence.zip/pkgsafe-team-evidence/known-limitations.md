# Known Limitations

- Team evidence is local-first and does not upload results to a hosted service.
- PkgSafe v1.0.0 remains npm-first GA; PyPI, Go, and Cargo are preview coverage and are not npm-equivalent.
- Heuristic behavior analysis is disabled by default and is non-isolated host execution when explicitly enabled.
- Missing repository paths are recorded as failed repo validations.
