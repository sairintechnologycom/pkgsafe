# small-npm-app

- Path: testdata/benchmarks/small-npm-app
- Ecosystems: npm
- Dependencies: 1 direct, 0 transitive, 2 total
- Allow / warn / block: 1 / 0 / 0
- False block: false
- Scanner crash: false
- JSON / SARIF / Markdown / Evidence pack: true / true / true / true
- Policy version: 1
- Scan timestamp: 2026-07-01T07:37:20Z
- PkgSafe version: v0.2.0-beta.1-3-gb09b204
- Status: pass

## Details
- full validation measured: 1 direct, 0 transitive, 1 source imports, inventory=1ms/98us ci_scan=1ms/133us output=1ms/350us evidence=1ms/308us total=1ms/588us
