# python-cli-app

- Path: testdata/benchmarks/python-cli-app
- Ecosystems: pypi
- Dependencies: 3 direct, 0 transitive, 3 total
- Allow / warn / block: 0 / 0 / 0
- False block: false
- Scanner crash: false
- JSON / SARIF / Markdown / Evidence pack: true / false / true / true
- Policy version: 1
- Scan timestamp: 2026-07-01T07:37:20Z
- PkgSafe version: v0.2.0-beta.1-3-gb09b204
- Status: pass

## Details
- full validation measured: 3 direct, 0 transitive, 0 source imports, inventory=1ms/157us ci_scan=0ms/0us output=1ms/756us evidence=1ms/747us total=1ms/916us
