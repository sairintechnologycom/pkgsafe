# npm-monorepo

- Path: testdata/benchmarks/npm-workspace-monorepo
- Ecosystems: npm
- Dependencies: 3 direct, 0 transitive, 5 total
- Allow / warn / block: 1 / 0 / 0
- False block: false
- Scanner crash: false
- JSON / SARIF / Markdown / Evidence pack: true / true / true / true
- Policy version: 1
- Scan timestamp: 2026-07-01T07:37:20Z
- PkgSafe version: v0.2.0-beta.1-3-gb09b204
- Status: pass

## Details
- full validation measured: 3 direct, 0 transitive, 2 source imports, inventory=1ms/313us ci_scan=1ms/271us output=1ms/360us evidence=1ms/342us total=1ms/947us
