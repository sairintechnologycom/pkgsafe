# larger-frontend-nextjs-app

- Path: testdata/benchmarks/nextjs-app
- Ecosystems: npm
- Dependencies: 4 direct, 0 transitive, 7 total
- Allow / warn / block: 1 / 0 / 0
- False block: false
- Scanner crash: false
- JSON / SARIF / Markdown / Evidence pack: true / true / true / true
- Policy version: 1
- Scan timestamp: 2026-07-01T07:37:20Z
- PkgSafe version: v0.2.0-beta.1-3-gb09b204
- Status: pass

## Details
- full validation measured: 4 direct, 0 transitive, 3 source imports, inventory=1ms/147us ci_scan=1ms/158us output=1ms/217us evidence=1ms/194us total=1ms/527us
