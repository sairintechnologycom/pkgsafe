# dashboard-vite-app

- Path: testdata/benchmarks/dashboard-vite-app
- Ecosystems: npm
- Dependencies: 5 direct, 0 transitive, 7 total
- Allow / warn / block: 1 / 0 / 0
- False block: false
- Scanner crash: false
- JSON / SARIF / Markdown / Evidence pack: true / true / true / true
- Policy version: 1
- Scan timestamp: 2026-07-01T07:37:20Z
- PkgSafe version: v0.2.0-beta.1-3-gb09b204
- Status: pass

## Details
- full validation measured: 5 direct, 0 transitive, 2 source imports, inventory=1ms/415us ci_scan=1ms/180us output=1ms/243us evidence=1ms/222us total=1ms/842us
