# node-backend-worker

- Path: testdata/benchmarks/node-backend-worker
- Ecosystems: npm
- Dependencies: 4 direct, 0 transitive, 8 total
- Allow / warn / block: 1 / 0 / 0
- False block: false
- Scanner crash: false
- JSON / SARIF / Markdown / Evidence pack: true / true / true / true
- Policy version: 1
- Scan timestamp: 2026-07-01T07:37:20Z
- PkgSafe version: v0.2.0-beta.1-3-gb09b204
- Status: pass

## Details
- full validation measured: 4 direct, 0 transitive, 4 source imports, inventory=1ms/288us ci_scan=1ms/355us output=1ms/261us evidence=1ms/237us total=1ms/909us
