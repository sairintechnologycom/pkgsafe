# node-backend-api

- Path: testdata/benchmarks/node-backend-api
- Ecosystems: npm
- Dependencies: 6 direct, 1 transitive, 9 total
- Allow / warn / block: 1 / 0 / 0
- False block: false
- Scanner crash: false
- JSON / SARIF / Markdown / Evidence pack: true / true / true / true
- Policy version: 1
- Scan timestamp: 2026-07-01T07:37:20Z
- PkgSafe version: v0.2.0-beta.1-3-gb09b204
- Status: pass

## Details
- full validation measured: 6 direct, 1 transitive, 2 source imports, inventory=1ms/180us ci_scan=1ms/238us output=1ms/245us evidence=1ms/231us total=1ms/666us
