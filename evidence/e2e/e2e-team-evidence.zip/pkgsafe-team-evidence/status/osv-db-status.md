# OSV DB Status

pass: OSV database is initialized
