# Release Verification Status

- checksums: verified
- checksums_verified: true
- provenance: configured
- provenance_verified: false
- sbom: present
- sbom_verified: true
- signed_release: configured
- signing_verified: false
