# PkgSafe Team Evidence

Generated: 2026-07-01T07:37:20Z

- Repositories: 15
- Passed / failed: 15 / 0
- Direct / transitive dependencies: 59 / 1
- Allow / warn / block: 12 / 0 / 0
- False blocks: 0
- Scanner crashes: 0
- PkgSafe version: v0.2.0-beta.1-3-gb09b204 (b09b204)

## Policy

- Source: embedded default
- Pack: default-policy@1
- Owner: local

## Repository Summary

| Repository | Ecosystems | Dependencies | Allow | Warn | Block | False block | Scanner crash | Status |
|---|---:|---:|---:|---:|---:|---:|---:|---|
| small-npm-app | npm | 2 | 1 | 0 | 0 | false | false | pass |
| react-vite-next-app | npm | 7 | 1 | 0 | 0 | false | false | pass |
| npm-monorepo | npm | 5 | 1 | 0 | 0 | false | false | pass |
| node-backend-api | npm | 9 | 1 | 0 | 0 | false | false | pass |
| python-requirements-app | pypi | 3 | 0 | 0 | 0 | false | false | pass |
| larger-frontend-nextjs-app | npm | 7 | 1 | 0 | 0 | false | false | pass |
| mixed-js-python-preview | npm, pypi | 4 | 1 | 0 | 0 | false | false | pass |
| npm-workspace-tools | npm | 7 | 1 | 0 | 0 | false | false | pass |
| npm-workspace-admin | npm | 10 | 1 | 0 | 0 | false | false | pass |
| node-backend-worker | npm | 8 | 1 | 0 | 0 | false | false | pass |
| node-backend-graphql | npm | 8 | 1 | 0 | 0 | false | false | pass |
| dashboard-vite-app | npm | 7 | 1 | 0 | 0 | false | false | pass |
| python-poetry-service | pypi | 4 | 0 | 0 | 0 | false | false | pass |
| python-cli-app | pypi | 3 | 0 | 0 | 0 | false | false | pass |
| internal-private-package-repo | npm | 7 | 1 | 0 | 0 | false | false | pass |

## OSV DB Status

pass: OSV database is initialized

## Release Verification

- checksums: verified
- checksums_verified: true
- provenance: configured
- provenance_verified: false
- sbom: present
- sbom_verified: true
- signed_release: configured
- signing_verified: false

## Known Limitations

- Team evidence is local-first and does not upload results to a hosted service.
- PkgSafe v1.0.0 remains npm-first GA; PyPI, Go, and Cargo are preview coverage and are not npm-equivalent.
- Heuristic behavior analysis is disabled by default and is non-isolated host execution when explicitly enabled.
- Missing repository paths are recorded as failed repo validations.
