# PkgSafe GA Candidate Evidence

Generated: 2026-06-29T10:32:31Z

## Readiness

- Current stage: PRIVATE_BETA_READY
- Private beta ready: true
- GA ready: false
- Real repo validations: 7 / 15
- GA blocker: real_repo_validation_count below GA threshold
- GA blocker: signed release artifacts not verified locally
- GA blocker: build provenance not verified locally

## Benchmark Summary

- Repos passed / failed: 7 / 0
- npm / PyPI / Go / Cargo repos: 6 / 2 / 0 / 0
- Average / p95 scan duration: 1ms / 3ms

## Ecosystem Depth

- npm: production-ready GA v1 scope after GA evidence gates pass
- pypi: preview coverage; not npm-equivalent
- go: preview metadata and OSV-oriented coverage; not npm-equivalent
- cargo: preview metadata and OSV-oriented coverage; not npm-equivalent

## Behavior Analysis

Private beta defaults behavior analysis to disabled. Heuristic mode is host execution; isolated mode reports unavailable until a real isolation backend exists.

## Security Gates

- rollout_readiness: pass: PRIVATE_BETA_READY
- policy_validation: pass: default policy is valid
- ci_outputs: pass: JSON, SARIF, and Markdown outputs generated
- OSV DB: pass: OSV database is initialized

## Release Artifacts

- provenance: configured
- provenance_verified: false
- signed_release: configured
- signing_verified: false
- checksums: verified
- checksums_verified: true
- sbom: present
- sbom_verified: true

## Known Limitations

- Real repo validation count may be below GA threshold.
- Isolated behavior backend is not implemented.
- PyPI/Go/Cargo remain preview until depth parity is implemented and validated.

## Recommendation

PRIVATE_BETA_READY: foundation gates passed; continue GA hardening (online benchmark, signed release, provenance, real-repo validation).
