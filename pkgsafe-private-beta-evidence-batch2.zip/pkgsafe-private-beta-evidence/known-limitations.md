# Known Limitations

- Real repo validation count may be below GA threshold.
- Isolated behavior backend is not implemented.
- PyPI/Go/Cargo depth is not npm-equivalent.

## Rollout Limitations
- npm has the strongest artifact and lifecycle-script coverage.
- PyPI, Go, and Cargo are not npm-equivalent yet.
- heuristic behavior mode executes on the host and is not sandboxing.
- isolated behavior mode is unavailable until a real backend lands.
- GA remains blocked until real repository validation and ecosystem-depth thresholds are met.
