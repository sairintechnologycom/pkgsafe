# PkgSafe Private Beta Evidence

Generated: 2026-06-29T00:45:47Z

## Readiness

- Current stage: PUBLIC_BETA_READY
- Private beta ready: true
- GA ready: false
- Real repo validations: 5 / 15
- GA blocker: real_repo_validation_count below GA threshold
- GA blocker: npm real repository count below GA threshold
- GA blocker: PyPI real repository count below GA threshold
- GA blocker: signed release artifacts not verified locally
- GA blocker: build provenance not verified locally
- GA blocker: isolated behavior backend unavailable
- GA blocker: PyPI/Go/Cargo depth not npm-equivalent

## Benchmark Summary

- Repos passed / failed: 5 / 0
- npm / PyPI / Go / Cargo repos: 4 / 1 / 0 / 0
- Average / p95 scan duration: 1ms / 1ms

## Ecosystem Depth

- npm: strongest private-beta coverage
- pypi: early coverage; not npm-equivalent
- go: metadata and OSV-oriented; not npm-equivalent
- cargo: metadata and OSV-oriented; not npm-equivalent

## Behavior Analysis

Private beta defaults behavior analysis to disabled. Heuristic mode is host execution; isolated mode reports unavailable until a real isolation backend exists.

## Security Gates

- rollout_readiness: pass: PRIVATE_BETA_READY
- policy_validation: pass: default policy is valid
- ci_outputs: pass: JSON, SARIF, and Markdown outputs generated
- OSV DB: pass: OSV database is initialized

## Release Artifacts

- signed_release: configured
- sbom: present
- provenance: configured

## Known Limitations

- Real repo validation count may be below GA threshold.
- Isolated behavior backend is not implemented.
- PyPI/Go/Cargo depth is not npm-equivalent.

## Recommendation

PUBLIC_BETA_READY: connected accuracy, action, and real-repo validation confirmed; finish signed-release + provenance verification for GA.
